﻿using System;
using System.Collections.Generic;
using System.Text;


    interface IFerrari
    {
        string DriverName{ get; }
    } 

