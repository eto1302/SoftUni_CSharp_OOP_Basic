﻿using System;
using System.Collections.Generic;
using System.Text;


interface IPeople
{
    string Name { get; }
    string Id { get; }
    int Age { get; }
    string Group { get; }
    DateTime BirthDate { get; }
}

