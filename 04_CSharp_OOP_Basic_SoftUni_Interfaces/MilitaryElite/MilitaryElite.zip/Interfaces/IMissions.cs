﻿using System;
using System.Collections.Generic;
using System.Text;

interface IMissions
{
    string codeName { get; }
    string state { get; }

    

}