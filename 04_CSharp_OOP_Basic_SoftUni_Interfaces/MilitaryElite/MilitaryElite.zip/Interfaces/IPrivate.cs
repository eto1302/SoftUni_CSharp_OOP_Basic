﻿using System;
using System.Collections.Generic;
using System.Text;

interface IPrivate : ISoldier
{
    
    double Salary { get; }
}

