﻿using System;
using System.Collections.Generic;
using System.Text;

interface IRepairs
{
    string partName { get; }
    int hoursWorked { get; }
}
