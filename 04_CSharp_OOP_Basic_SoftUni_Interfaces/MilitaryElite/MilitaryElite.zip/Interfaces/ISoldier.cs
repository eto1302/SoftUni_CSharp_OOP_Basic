﻿using System;
using System.Collections.Generic;
using System.Text;

interface ISoldier
{
    string Id { get; }
    string FirstName { get; }
    string LastName { get; }
}
