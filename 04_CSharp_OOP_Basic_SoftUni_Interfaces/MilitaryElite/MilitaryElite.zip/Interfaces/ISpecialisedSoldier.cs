﻿using System;
using System.Collections.Generic;
using System.Text;
interface ISpecialisedSoldier : IPrivate
{
    string Corps { get; }
}
