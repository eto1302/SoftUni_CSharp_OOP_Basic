﻿using System;
using System.Collections.Generic;
using System.Text;

interface ISpy : ISoldier
{
    int CodeNumber { get; }
}
