﻿using System;
using System.Collections.Generic;
using System.Text;


    interface IBrowse
    {
        string Browse(string url);
    }
