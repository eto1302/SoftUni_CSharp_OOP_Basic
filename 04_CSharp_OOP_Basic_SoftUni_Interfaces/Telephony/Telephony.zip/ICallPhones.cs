﻿using System;
using System.Collections.Generic;
using System.Text;
interface ICallPhones
{
    string Call(string number);


}

