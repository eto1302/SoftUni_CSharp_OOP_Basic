﻿using System;
using System.Collections.Generic;
using System.Text;

class Meat : Food
{
    public Meat(int quantity) : base(quantity)
    {

    }
}
