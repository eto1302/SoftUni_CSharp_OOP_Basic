﻿using System;
using System.Collections.Generic;
using System.Text;

class Seeds : Food
{
    public Seeds(int quantity) : base(quantity)
    {
        
    }
}
